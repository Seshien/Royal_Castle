#include "model.h"
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <iostream>

using namespace std;

std::ostream& operator<<(std::ostream& out, glm::mat4 m) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            out << m[i][j] << " ";
        }
        out << "\n";
    }
    return out;
}
 
std::ostream& operator<<(std::ostream& out, glm::vec4 v) {
    for (int i = 0; i < 4; i++) out << v[i] << " ";
    return out;
}
  
 /*   void Model::create_cuboid()           //nie jest potrzebny model sam w sobie, 
                                            //to jest tylko po to �eby sobie    
                                            //uwidoczni� jak wygl�da taki prostopadloscian
                                    
    {
        cuboid.push_back(wierzcholki[0]);
        cuboid.push_back(wierzcholki[4]);
        cuboid.push_back(wierzcholki[5]);
        cuboid.push_back(wierzcholki[0]);
        cuboid.push_back(wierzcholki[4]);
        cuboid.push_back(wierzcholki[2]);
        cuboid.push_back(wierzcholki[0]);
        cuboid.push_back(wierzcholki[1]);
        cuboid.push_back(wierzcholki[2]);
        cuboid.push_back(wierzcholki[3]);
        cuboid.push_back(wierzcholki[1]);
        cuboid.push_back(wierzcholki[2]);
        cuboid.push_back(wierzcholki[3]);
        cuboid.push_back(wierzcholki[1]);
        cuboid.push_back(wierzcholki[5]);
        cuboid.push_back(wierzcholki[3]);
        cuboid.push_back(wierzcholki[4]);
        cuboid.push_back(wierzcholki[5]);
        cuboid.push_back(wierzcholki[3]);
        cuboid.push_back(wierzcholki[4]);
        cuboid.push_back(wierzcholki[2]);
        cuboid.push_back(wierzcholki[0]);
        cuboid.push_back(wierzcholki[1]);
        cuboid.push_back(wierzcholki[5]);
    }*/

    void Model::change_cuboid()
    {
            cuboid_ver = glm::vec4((GLfloat)wierzcholki[0], (GLfloat)wierzcholki[1], (GLfloat)wierzcholki[2], 1.0f);
            cuboid_ver = Mat*cuboid_ver;
            wierzcholki[0] = cuboid_ver.x;
            wierzcholki[1] = cuboid_ver.y;
            wierzcholki[2] = cuboid_ver.z;
               
            cuboid_ver = glm::vec4((GLfloat)wierzcholki[3], (GLfloat)wierzcholki[4], (GLfloat)wierzcholki[5], 1.0f);
            cuboid_ver = Mat * cuboid_ver;
            wierzcholki[3] = cuboid_ver.x;
            wierzcholki[4] = cuboid_ver.y;
            wierzcholki[5] = cuboid_ver.z;

            for (int i = 0; i < 3; i++)
                if (wierzcholki[i] < wierzcholki[i + 3]) swap(wierzcholki[i], wierzcholki[i + 3]);

    //    create_cuboid();
    }

    void  Model::drawSolid()
    {
        glEnableVertexAttribArray(0);
        glEnableVertexAttribArray(1);
        glEnableVertexAttribArray(2);

        glVertexAttribPointer(0, 4, GL_FLOAT, false, 0, vertices.data());
        glVertexAttribPointer(1, 4, GL_FLOAT, false, 0, vertexNormals.data());
        glVertexAttribPointer(2, 4, GL_FLOAT, false, 0, texCoords.data());

        glDrawArrays(GL_TRIANGLES, 0, vertices.size() / 4);

        glDisableVertexAttribArray(0);
        glDisableVertexAttribArray(1);
        glDisableVertexAttribArray(2);
    }
