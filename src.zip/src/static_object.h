#pragma once
#include "model.h"
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>


class static_object : public Model
{
public:
	std::string path;
	glm::vec3 position, scale, rotate;
	float angle;
	glm::vec3 color;
	void load_model();
	static_object();
	static_object (std::string path, glm::vec3 position, glm::vec3 scale,float angle, glm::vec3 rotate, glm::vec3 color);
	void create_object();
	bool collision(glm::vec3);	
};

